<?php
define('MYSQL_HOST','192.168.1.23');
define('MYSQL_USER','root');
define('MYSQL_PASS','jsjxjf');
define('DATABASE','radiusdb');

class Table
{
    public static $db=null;
    private $_tb;

    public function __construct($tbName)
    {
        $db=self::$db;
        if(!$db)
        {
            $db=new mysqli(MYSQL_HOST,MYSQL_USER,MYSQL_PASS,DATABASE);
            if($db->connect_error)
            {
                exit("Connect Error message :".$db->connect_error);
            }
            else
            {
                self::$db=$db;
            }
        }
        $this->_tb=$tbName;
        $db->set_charset("utf8");
    }

    public function q(&$a)
    {
        foreach ($a as $k=>&$v)
        {
            if(is_string($v))
            {
                $v="'$v'";
            }
        }
    }

    public function save($a, $insert=true,$where=[])
    {
        $this->q($a);
        if($insert)
        {
            $ks=array_keys($a);
            foreach($ks as $k)
            {
                $vs[]=$a[$k];
            }
            $kstr=implode($ks,",");
            $vstr=implode($vs,",");
            $sql="insert into {$this->_tb} ($kstr) values($vstr)";
        }
        else
        {
            $sql="update {$this->_tb} set ";
            foreach ($a as $k=>$v)
            {
                $sql.="$k=$v,";
            }
            $sql=rtrim($sql,",");
            $this->q($where);
            $sql.=" where 1";
            foreach ($where as $k=>$v)
            {
                $sql.=" and $k=$v";
            }
        }
        $db=self::$db;
        return $db->query($sql) && $db->affected_rows>0;
    }

    public function delete($where)
    {
        $this->q($where);
        $sql="delete from {$this->_tb} where 1";
        foreach ($where as $k=>$v)
        {
            $sql.=" and $k=$v";
        }
        $db=self::$db;
        return $db->query($sql) && $db->affected_rows>0;
    }

    public function selectBySql($sql)
    {
        $db=self::$db;
        $result=$db->query($sql);
        if($result && $result->num_rows>0)
        {
            return $result;
        }
        return false;
    }

    public function escape($v)
    {
        $db=self::$db;
        return $db->real_escape_string($v);
    }
}