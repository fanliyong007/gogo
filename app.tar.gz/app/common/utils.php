<?php

function formatBytes($n)
{
    $units=['Bytes','KB','MB','GB'];
    $i=0;
    while($n /1024>=1)
    {
        $i++;
        $n=$n/1024;
    }
    return sprintf($i==0?"%d":"%.3f",$n).$units[$i];
}

function formatSeconds($n)
{
    $units=['Sec','Min','Hour'];
    do
    {
        $r=$n%60;
        $rs[]=$r;
        $n=intval($n/60);
        if(count($rs)>=3) break;
    }
    while($n>=1);

    $str='';
    $flag=false;
    for($i=0;$i<count($rs);$i++)
    {
        if($flag || $rs[$i]>0)
        {
            $str=$rs[$i].' '.$units[$i].' '.$str;
            $flag=true;
        }
    }
    return $str;
}