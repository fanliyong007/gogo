<?php
if(!isset($_SESSION['id']))
{
    if(isset($_GET['msg']))
    {
        ?>
            <span class="text-danger text-center"><h3>Username or password is wrong</h3></span>
        <?php
    }
    ?>
        <form class="col-md-4 col-md-offset-4" action="?url=login/loginin.php" method="post">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control" placeholder="please input username">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control" placeholder="please input passworsd">
            </div>
            <div class="form-group">
                <label class="radio-inline"><input type="radio" name="grade" value="0" checked>Administrator</label>
                <label class="radio-inline"><input type="radio" name="grade" value="1" >User</label>
            </div>
            <input type="submit" class="btn btn-success" value="login">
        </form>
        <div class="col-md-4 col-md-offset-4 text-center">
            <h4>If you don't have an account ,you can click <a href="?url=register/register.php">Sign up</a> to register an account!</h4>
        </div>
    <?php
}
else
{
    header("location:?url=online/online.php");
}