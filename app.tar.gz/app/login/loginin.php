<?php
require_once '../common/Table.php';
if(!isset($_SESSION['id']))
{
    $grade=$_POST['grade']==0?"administrator":"radcheck";
    $db=new Table($grade);
    $username=$db->escape($_POST['username']);
    $password=$db->escape($_POST['password']);
    $sql="select * from {$grade} where username='{$username}' and value='{$password}'";
    $result=$db->selectBySql($sql);
    if($result)
    {
        if($row=mysqli_fetch_assoc($result))
        {
            $_SESSION['id']=$row['id'];
            $_SESSION['username']=$row['username'];
            $_SESSION['grade']=$_POST['grade'];
        }
        header("location:?url=online/online.php");
    }
    else
    {
        header("location:?url=login/login.php&msg=yes");
    }

}