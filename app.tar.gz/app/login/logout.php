<?php
if(isset($_SESSION['id']))
{
    session_destroy();
    setcookie("session_id","",time()-3600);
    header("location:?url=login/login.php");
}