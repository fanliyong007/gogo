<?php
require_once '../common/Table.php';
if(isset($_SESSION['id']))
{
    if($_SESSION['grade']==0)
    {
        $db=new Table('radpostauth');
        $sql="select * from radpostauth";
        $result=$db->selectBySql($sql);
        if($result)
        {
            ?>
            <div class="navbar-form navbar-right">
                <a href="csvout.php?tab=activity" class="btn btn-success">Export</a>
            </div>
            <table class="table table-striped">
                <thead>
                <tr>
                    <th class="text-center">Id</th>
                    <th class="text-center">User Name</th>
                    <th class="text-center">Activity</th>
                    <th class="text-center">Date Time</th>
                </tr>
                </thead>
                <tbody>
                <?php while($row=mysqli_fetch_assoc($result)):?>
                    <tr>
                        <td class="text-center"><?=$row['id']?></td>
                        <td class="text-center"><?=$row['username']?></td>
                        <td class="text-center"><?=$row['reply']?></td>
                        <td class="text-center"><?=$row['authdate']?></td>
                    </tr>
                <?php endwhile;?>
                </tbody>
            </table>
            <?php
        }
    }
}
else
{
    ?>
    <script>alert("Please Login first")</script>
    <?php
    header("Refresh:0.1;url=?url=login/login.php");
}