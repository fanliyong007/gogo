<?php
require_once '../common/Table.php';
if(isset($_SESSION['id']))
{
    if($_SESSION['grade']==0)
    {
        $raddb=new Table('radcheck');
        $username=$raddb->escape($_GET['username']);
        $sqlcount="select count(*) from radcheck where username='{$username}'";
        $count=mysqli_fetch_assoc($raddb->selectBySql($sqlcount))['count(*)'];
        if($count>0)
        {
            $resultR=$raddb->delete(['username'=>$username]);
        }
        else $resultR=true;

        $intdb=new Table('internetuser');
        $resultU=$intdb->delete(['username'=>$username]);

        $groupdb=new Table('radusergroup');
        $resultG=$groupdb->delete(['username'=>$username]);
        if($resultR and $resultU and $resultG)
        {
            ?>
                <script>alert("Delete success");</script>
            <?php
            header("Refresh:0.1;url=?url=online/userinfo.php");
        }
    }
}