<?php
require_once '../common/Table.php';
if(isset($_SESSION['id']))
{
    if($_SESSION['grade']==0)
    {
        $db=new Table('internetuser');
        $username=$db->escape($_GET['username']);
        $sql="select * from internetuser where username='{$username}'";
        $result=$db->selectBySql($sql);
        if($result)
        {
            if($row=mysqli_fetch_assoc($result))
            {
                if(isset($_GET['msg']))
                {
                    ?>
                    <span class="text-danger text-center"><h3>Username is exist</h3></span>
                    <?php
                }
                ?>
                <form class="col-md-4 col-md-offset-4" action="?url=online/admin-up.php" method="post">
                    <input type="hidden" name="oldname" value="<?= $row['username'] ?>">
                    <div class="form-group">
                        <label>Username</label>
                        <input type="text" name="username" class="form-control" value="<?= $row['username'] ?>">
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" class="form-control" value="<?= $row['value'] ?>">
                    </div>
                    <div class="form-group">
                        <label>Gender</label><br>
                        <label class="radio-inline"><input type="radio" name="gender"
                                                           value="male" <?= $row['gender'] == "male" ? "checked" : "" ?>>male</label>
                        <label class="radio-inline"><input type="radio" name="gender"
                                                           value="female" <?= $row['gender'] == "female" ? "checked" : "" ?>>female</label>
                    </div>
                    <div class="form-group">
                        <label>Group</label>
                        <select name="group" class="form-control">
                            <option value="student" <?= $row['group'] == "student" ? "selected" : "" ?>>student</option>
                            <option value="teacher" <?= $row['group'] == "teacher" ? "selected" : "" ?>>teacher</option>
                            <option value="student" <?= $row['group'] == "director" ? "selected" : "" ?>>director
                            </option>
                            <option value="guest" <?= $row['group'] == "guest" ? "selected" : "" ?>>guest</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Details</label>
                        <textarea cols="3" class="form-control" name="details"><?= $row['details'] ?></textarea>
                    </div>
                    <input type="submit" class="btn btn-success" value="save">
                </form>
                <?php
            }
        }
    }
}