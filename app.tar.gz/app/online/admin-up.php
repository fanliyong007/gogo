<?php
require_once '../common/Table.php';
if(isset($_SESSION['id']))
{
    if($_SESSION['grade']==0)
    {
        $intdb=new Table('internetuser');
        $username=$intdb->escape($_POST['username']);
        $oldname=$intdb->escape($_POST['oldname']);
        $password=$intdb->escape($_POST['password']);
        $count=0;
        if($oldname!=$username)
        {
            $sqlcount="select count(*) from internetuser where username='{$username}'";
            $count=mysqli_fetch_assoc($intdb->selectBySql($sqlcount))['count(*)'];
            if($count>0)
            {
                header("location:?url=online/admin-modi.php&username=".$oldname."&msg=yes");
            }
        }
        if($count==0)
        {
            $gender=$intdb->escape($_POST['gender']);
            $group=$intdb->escape($_POST['group']);
            $details=$intdb->escape($_POST['details']);
            $resultU=$intdb->save(['username'=>$username,'value'=>$password,'gender'=>$gender,'`group`'=>$group,'details'=>$details],false,['username'=>$oldname]);

            $rad=new Table('radcheck');
            $resultR=$rad->save(['username'=>$username,'value'=>$password],false,['username'=>$oldname]);

            $groupdb=new Table('radusergroup');
            $resultG=$groupdb->save(['username'=>$username,'groupname'=>$group],false,['username'=>$oldname]);
            if($resultU or $resultR or $resultG)
            {
                ?>
                    <script>alert('Update success');</script>
                <?php
                header("Refresh:0.1;url=?url=online/userinfo.php");
            }
        }

    }
}