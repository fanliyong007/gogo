<?php
if(isset($_SESSION['id']))
{
    ?>
        <table class="table table-striped">
            <caption class="text-center"><h3>Functions Summary</h3></caption>
            <thead>
                <tr>
                    <th class="text-center">System name</th>
                    <th class="text-center">Comment</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="text-center"><a href="?url=online/usermodi.php">Editing Personal Info</a></td>
                    <td class="text-center">Change user personal information</td>
                </tr>
                <?php if($_SESSION['grade']==0):?>
                    <tr>
                        <td class="text-center"><a href="?url=online/userinfo.php">User Information List</a></td>
                        <td class="text-center">Administrator change user system(create new user,delete user,disable user)</td>
                    </tr>
                    <tr>
                        <td class="text-center"><a href="?url=online/activity.php">Network Activity</a></td>
                        <td class="text-center">Network activity checking system</td>
                    </tr>
                    <tr>
                        <td class="text-center"><a href="?url=online/report.php">Network Report</a></td>
                        <td class="text-center">Network activity report-generating system</td>
                    </tr>
                <?php endif;?>
            </tbody>
        </table>
    <?php
}
else
{
    ?>
        <script>alert("Please Login first")</script>
    <?php
    header("Refresh:0.1;url=?url=login/login.php");
}