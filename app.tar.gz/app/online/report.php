<?php
require_once '../common/Table.php';
if(isset($_SESSION['id']))
{
    if($_SESSION['grade']==0)
    {
        $db=new Table('radacct');
        $sql="select * from radacct";
        $result=$db->selectBySql($sql);
        include ('../common/utils.php');
        $count=0;
        if($result)
        {
            ?>
            <div class="navbar-form navbar-right">
                <a href="csvout.php?tab=report" class="btn btn-success">Export</a>
            </div>
            <table class="table table-striped">
                <thead>
                <tr>
                    <th class="text-center">#</th>
                    <th class="text-center">User Name</th>
                    <th class="text-center">User IP</th>
                    <th class="text-center">Start Time</th>
                    <th class="text-center">Stop Time</th>
                    <th class="text-center">Session Time</th>
                    <th class="text-center">Upload(Bytes)</th>
                    <th class="text-center">Download(Bytes)</th>
                    <th class="text-center">Nas IP</th>
                </tr>
                </thead>
                <tbody>
                <?php while($row=mysqli_fetch_assoc($result)):?>
                    <tr>
                        <td class="text-center"><?=++$count?></td>
                        <td class="text-center"><?=$row['username']?></td>
                        <td class="text-center"><?=$row['framedipaddress']?></td>
                        <td class="text-center"><?=$row['acctstarttime']?></td>
                        <td class="text-center"><?=$row['acctstoptime']?></td>
                        <td class="text-center"><?=formatSeconds($row['acctsessiontime'])?></td>
                        <td class="text-center"><?=formatBytes($row['acctinputoctets'])?></td>
                        <td class="text-center"><?=formatBytes($row['acctoutputoctets'])?></td>
                        <td class="text-center"><?=$row['nasipaddress']?></td>
                    </tr>
                <?php endwhile;?>
                </tbody>
            </table>
            <?php
        }
    }
}
else
{
    ?>
    <script>alert("Please Login first")</script>
    <?php
    header("Refresh:0.1;url=?url=login/login.php");
}