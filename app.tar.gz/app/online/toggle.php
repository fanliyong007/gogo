<?php
require_once '../common/Table.php';
if(isset($_SESSION['id']))
{
    if($_SESSION['grade']==0)
    {
        $raddb=new Table('radcheck');
        $username=$raddb->escape($_GET['username']);
        $password=$raddb->escape($_GET['password']);
        $sqlcount="select count(*) from radcheck where username='{$username}' and value='{$password}'";
        $count=mysqli_fetch_assoc($raddb->selectBySql($sqlcount))['count(*)'];
        if($count>0)
        {
            $resultR=$raddb->delete(['username'=>$username]);

            $intdb=new Table('internetuser');
            $resultU=$intdb->save(['active'=>'0'],false,['username'=>$username]);
            if($resultU and $resultR)
            {
                ?>
                    <script>alert("Disable success");</script>
                <?php
                header("Refresh:0.1;url=?url=online/userinfo.php");
            }
        }
        else
        {
            $resultR=$raddb->save(['username'=>$username,'attribute'=>'Cleartext-Password','op'=>':=','value'=>$password]);

            $intdb=new Table('internetuser');
            $resultU=$intdb->save(['active'=>'1'],false,['username'=>$username]);
            if($resultU and $resultR)
            {
                ?>
                <script>alert("Enable success");</script>
                <?php
                header("Refresh:0.1;url=?url=online/userinfo.php");
            }
        }
    }
}