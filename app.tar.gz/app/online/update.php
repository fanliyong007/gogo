<?php
require_once '../common/Table.php';
if(isset($_SESSION['id']))
{
    $grade=$_SESSION['grade']==0?"administrator":"radcheck";
    $db=new Table($grade);
    $username=$db->escape($_POST['username']);
    //$oldpass=$db->escape($_POST['oldpass']);
    $password=$db->escape($_POST['password']);

    $result=$db->save(['username'=>$username,'value'=>$password],false,['username'=>$username]);

    if($_SESSION['grade']==1)
    {
        $intdb=new Table('internetuser');
        $gender=$intdb->escape($_POST['gender']);
        $details=$intdb->escape($_POST['details']);

        $resultU=$intdb->save(['username'=>$username,'value'=>$password,'gender'=>$gender,'details'=>$details],false,['username'=>$username]);

        if ($result or $resultU)
        {
            ?>
            <script>alert('Update success');</script>
            <?php
            header("Refresh:0.1;url=?url=online/usermodi.php");
        }
    }
    else
    {
        if ($result) {
            ?>
            <script>alert('Update success');</script>
            <?php
            header("Refresh:0.1;url=?url=online/usermodi.php");
        }
    }
}
