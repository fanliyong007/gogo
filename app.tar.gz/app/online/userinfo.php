<?php
require_once '../common/Table.php';
if(isset($_SESSION['id']))
{
    if($_SESSION['grade']==0)
    {
        $intdb=new Table('internetuser');
        $sql="select * from internetuser";
        $result=$intdb->selectBySql($sql);
        $count=0;
        if($result)
        {
            ?>
                <div class="navbar-form navbar-right">
                <a href="csvout.php?tab=userinfo" class="btn btn-success">Export</a>
                </div>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th class="text-center">#</th>
                            <th class="text-center">User Name</th>
                            <th class="text-center">Gender</th>
                            <th class="text-center">Group</th>
                            <th class="text-center">Details</th>
                            <th class="text-center">Operations</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row=mysqli_fetch_assoc($result)):?>
                        <tr>
                            <td class="text-center"><?=++$count;?></td>
                            <td class="text-center"><?=$row['username']?></td>
                            <td class="text-center"><?=$row['gender']?></td>
                            <td class="text-center"><?=$row['group']?></td>
                            <td class="text-center"><?=$row['details']?></td>
                            <td class="text-center">
                                <a href="?url=online/toggle.php&username=<?=$row['username']?>&password=<?=$row['value']?>" class="btn <?=$row['active']==1?"btn-success":"btn-danger";?>"><?=$row['active']==1?"Disable":"Enable"?></a>&nbsp;
                                <a href="?url=online/admin-modi.php&username=<?=$row['username']?>" class="btn btn-success">Update</a>&nbsp;
                                <a href="?url=online/admin-del.php&username=<?=$row['username']?>" class="btn btn-danger">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile;?>
                    </tbody>
                </table>
            <?php
        }
    }
}
else
{
    ?>
    <script>alert("Please Login first")</script>
    <?php
    header("Refresh:0.1;url=?url=login/login.php");
}