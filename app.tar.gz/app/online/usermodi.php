<?php
require_once '../common/Table.php';
if(isset($_SESSION['id']))
{
    $grade=$_SESSION['grade']==0?"administrator":"internetuser";
    $db=new Table($grade);
    $username=$db->escape($_SESSION['username']);
    $sql="select * from {$grade} where username='{$username}'";
    $result=$db->selectBySql($sql);
    if($result)
    {
        if($row=mysqli_fetch_assoc($result))
        {
            ?>
            <form class="col-md-4 col-md-offset-4" action="?url=online/update.php" method="post">
                <div class="form-group">
                    <label>Username</label>
                    <input type="text" name="username" class="form-control" value="<?= $row['username'] ?>" readonly>
                </div>
                <div class="form-group">
                    <label>Old Password</label>
                    <input type="password" name="oldpass" class="form-control" value="<?= $row['value'] ?>" readonly>
                </div>
                <div class="form-group">
                    <label>New Password</label>
                    <input type="password" name="password" class="form-control" value="<?= $row['value'] ?>">
                </div>
                <?php if ($_SESSION['grade'] == 1): ?>
                    <div class="form-group">
                        <label>Gender</label><br>
                        <label class="radio-inline"><input type="radio" name="gender" value="male" <?= $row['gender'] == "male" ? "checked" : "" ?>>male</label>
                        <label class="radio-inline"><input type="radio" name="gender" value="female" <?= $row['gender'] == "female" ? "checked" : "" ?>>female</label>
                    </div>
                    <div class="form-group">
                        <label>Group</label>
                        <input type="text" name="group" class="form-control" value="<?= $row['group'] ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label>Details</label>
                        <textarea cols="3" class="form-control" name="details"><?= $row['details'] ?></textarea>
                    </div>
                <?php endif; ?>
                <input type="submit" class="btn btn-success" value="save">
            </form>
            <?php
        }
    }
}
else
{
    ?>
    <script>alert("Please Login first")</script>
    <?php
    header("Refresh:0.1;url=?url=login/login.php");
}