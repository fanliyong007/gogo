<?php
require_once '../common/Table.php';
if(!isset($_SESSION['id']))
{
    $intdb=new Table('internetuser');
    $username=$intdb->escape($_POST['username']);
    $password=$intdb->escape($_POST['password']);
    $sqlcount="select count(*) from internetuser where username='{$username}'";
    $count=mysqli_fetch_assoc($intdb->selectBySql($sqlcount))['count(*)'];
    $a=true;
    if($count>0)
    {
        $a=false;
        header("location:?url=register/register.php&msg=yes");
    }
    if($a)
    {
        $resultU=$intdb->save(['username'=>$password,'value'=>$password,'`group`'=>'student']);

        $raddb=new Table('radcheck');
        $resultR=$raddb->save(['username'=>$username,'attribute'=>'Cleartext-Password','op'=>':=','value'=>$password]);

        $groupdb=new Table('radusergroup');
        $resultG=$groupdb->save(['username'=>$username,'groupname'=>'student']);

        if($resultG and $resultR and $resultU)
        {
            ?>
                <script>alert('Register success')</script>
            <?php
            header("Refresh:0.1;url=?url=login/login.php");
        }

    }
}
else
{
    header("location:?url=online/online.php");
}