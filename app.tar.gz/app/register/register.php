<?php
if(!isset($_SESSION['id']))
{
    if(isset($_GET['msg']))
    {
        ?>
        <span class="text-danger text-center"><h3>Username is exist</h3></span>
        <?php
    }
    ?>
    <form class="col-md-4 col-md-offset-4" action="?url=register/reg.php" method="post" onsubmit="return check(this);">
        <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" class="form-control" placeholder="please input username">
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" class="form-control" placeholder="please input passworsd">
        </div>
        <div class="form-group">
            <label>Confirm</label>
            <input type="password" name="confirm" class="form-control" placeholder="please repeat passworsd">
        </div>
        <input type="submit" class="btn btn-success" value="register">
    </form>
    <?php
}
else
{
    header("location:?url=online/online.php");
}