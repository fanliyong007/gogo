<?php
require_once '../common/Table.php';
session_start();
if(isset($_SESSION['id']))
{
    if($_SESSION['grade']==0)
    {
        $tab=$_GET['tab'];
        if($tab=="userinfo")
        {
            $db=new Table('internetuser');
            $sql="select * from internetuser";
            $result=$db->selectBySql($sql);
            header("Content-Disposition:attachment; filename=UserInfo.csv");
            echo "id,username,value,gender,group,details\r\n";
            while($row=mysqli_fetch_assoc($result))
            {
                echo "{$row['id']},{$row['username']},{$row['value']},{$row['gender']},{$row['group']},{$row['details']}\r\n";
            }
            exit;
        }
        else if($tab=="report")
        {
            include ('../common/utils.php');
            $db=new Table('radacct');
            $sql="select * from radacct";
            $result=$db->selectBySql($sql);
            header("Content-Disposition:attachment; filename=NetworkReport.csv");
            echo "radacctid,username,framedipaddress,acctstarttime,acctstoptime,acctsessiontime,acctinputoctets,acctoutputoctets,nasipaddress\r\n";
            while($row=mysqli_fetch_assoc($result))
            {
                echo "{$row['radacctid']},{$row['username']},{$row['framedipaddress']},{$row['acctstarttime']},{$row['acctstoptime']},{$row['acctsessiontime']},{$row['acctinputoctets']},{$row['acctoutputoctets']},{$row['nasipaddress']}\r\n";
            }
            exit;
        }
        else if($tab=="activity")
        {
            $db=new Table('radpostauth');
            $sql="select * from radpostauth";
            $result=$db->selectBySql($sql);
            header("Content-Disposition:attachment; filename=NetworkActivity.csv");
            echo "id,username,pass,reply,authdate\r\n";
            while($row=mysqli_fetch_assoc($result))
            {
                echo "{$row['id']},{$row['username']},{$row['pass']},{$row['reply']},{$row['authdate']}\r\n";
            }
            exit;
        }
    }
}