<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Internet User Management System</title>

<!-- Bootstrap -->
<link href="css/bootstrap.css" rel="stylesheet">

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <script type="text/javascript">
        function check(form)
        {
            if(form.username.value=="")
            {
                alert('Username is null');
                return false;
            }
            if(form.password.value=="")
            {
                alert('password is null');
                return false;
            }
            if(form.password.value!=form.confirm.value)
            {
                alert('Password is not equal confirm');
                return false;
            }
        }
    </script>
</head>
<body>
<?php
    session_start();
    setcookie("session_id",session_id(),time()+3600)
?>
<nav class="navbar navbar-default">
  <div class="container-fluid"> 
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#defaultNavbar1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
      <a class="navbar-brand" href="#">ZIME</a></div>
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="defaultNavbar1">
      <ul class="nav navbar-nav">
        <?php if(isset($_SESSION['id'])):?>
            <div class="navbar-header">
                <span type="button" class="navbar-brand"><?=$_SESSION['grade']==0?"(ADMINISTRATOR)":"(USER)"?></div>
          <?php if($_SESSION['grade']==0):?>
                <?php if(@$_GET['url']!="online/online.php"):?>
                    <li><a href="?url=online/online.php">Home</a></li>
                <?php endif;?>
                <li><a href="?url=online/userinfo.php">User Infor</a></li>
                <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Network<span class="caret"></span></a>
                  <ul class="dropdown-menu" role="menu">
                    <li><a href="?url=online/activity.php">Activity</a></li>
                    <li><a href="?url=online/report.php">Report</a></li>
                  </ul>
                </li>
            <?php endif;?>
        <?php endif;?>
      </ul>
      <!--<form class="navbar-form navbar-left" role="search">
        <div class="form-group">
          <input type="text" class="form-control" placeholder="Search">
        </div>
        <button type="submit" class="btn btn-default">Submit</button>
      </form>-->
      <ul class="nav navbar-nav navbar-right">
        <?php if(!isset($_SESSION['id'])):?>
          <li><a href="?url=login/login.php">Login</a></li>
        <?php endif;?>
          <?php if(isset($_SESSION['id'])):?>
              <li><a href="?url=online/usermodi.php">Personal Info</a></li>
              <li><a href="?url=login/logout.php">Logout(<?=$_SESSION['username']?>)</a></li>
          <?php endif;?>
      </ul>
    </div>
    <!-- /.navbar-collapse --> 
  </div>
  <!-- /.container-fluid --> 
</nav>
<div class="container-fluid">
  <div class="row">
    <div class="col-md-6 col-md-offset-3">
      <h1 class="text-center">
          <?php
                switch(@$_GET['url'])
                {
                    case "online/userinfo.php":echo "User Information List";break;
                    case "online/activity.php":echo "Network Activity";break;
                    case "online/report.php":echo "Network Report";break;
                    default:echo "Internet User Management System";break;
                }
          ?>
      </h1>
    </div>
  </div>
  <hr>
</div>
<div class="container">
        <div class="col-md-10 col-md-offset-1">
                <?php
                    if(isset($_GET['url']))
                    {
                        $url=$_GET['url'];
                    }
                    else $url="login/login.php";
                    include (dirname(dirname(__FILE__))."/".$url);
                ?>
        </div>
  <hr class="col-md-12">
  <div class="row">
    <div class="text-center col-md-6 col-md-offset-3">
      <h4>&copy;Made By ZIME CHINA </h4>
    </div>
  </div>
  <hr>
</div>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="js/jquery-1.11.3.min.js"></script>

<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="js/bootstrap.js"></script>
</body>
</html>
