<?php
	header("Location:/?url=register/register.php");
?>
